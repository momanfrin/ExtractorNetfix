﻿CREATE TABLE [dbo].[PaisOrigem]
(
	[IdPais] NVARCHAR(50) NOT NULL PRIMARY KEY, 
    [NomePais] NVARCHAR(100) NULL, 
    [Ativo] BIT NULL
)
